class DriverRequest(object):
    def __init__(self):
        self.actions = []
