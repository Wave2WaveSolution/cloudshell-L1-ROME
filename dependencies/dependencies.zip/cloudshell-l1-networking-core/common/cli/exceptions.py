class SessionLoopLimitException(Exception):
    pass


class SessionLoopDetectorException(Exception):
    pass


class CommandExecutionException(Exception):
    pass
